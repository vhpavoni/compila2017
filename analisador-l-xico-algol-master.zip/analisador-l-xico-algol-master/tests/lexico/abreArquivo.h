//
// Created by sutil on 20/12/16.
//

#ifndef PROJETOU_ABREARQUIVO_H
#define PROJETOU_ABREARQUIVO_H

#include <string>
using namespace std;
FILE *criaArquivo(string conteudo);

void fechaERemove(FILE * f);

#endif //PROJETOU_ABREARQUIVO_H
