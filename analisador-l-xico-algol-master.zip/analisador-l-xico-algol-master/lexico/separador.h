//
// Created by sutil on 16/12/16.
//

#ifndef PROJETOU_SEPARADOR_H
#define PROJETOU_SEPARADOR_H

bool isSeparadorDescartavel(char caraceter);

bool isSeparadorNaoDescartavel(char caracter);

bool isSeparadorComSequencia(char caracter);

bool isSeparador(char cararcter);

#endif //PROJETOU_SEPARADOR_H
