//
// Created by sutil on 16/12/16.
//

#ifndef PROJETOU_DEFINIDORTOKEN_H
#define PROJETOU_DEFINIDORTOKEN_H

#include <string>

using namespace std;

bool isNumero(string valor);

string getTipoToken(string valor);

#endif //PROJETOU_DEFINIDORTOKEN_H
