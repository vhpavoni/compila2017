//
// Created by Victor on 16/10/2016.
//

#ifndef PREDICTIONTABLE_GERATABELA_H
#define PREDICTIONTABLE_GERATABELA_H

    #include <stdio.h>
    #include <string.h>

    struct matriz
    {
    char tabResult[150][150];

    };

#endif //PREDICTIONTABLE_GERATABELA_H
