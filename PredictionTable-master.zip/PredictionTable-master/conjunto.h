//
// Created by sutil on 13/10/16.
//

#ifndef PREDICTIONTABLE_CONJUNTO_H
#define PREDICTIONTABLE_CONJUNTO_H

#include <stdio.h>

struct conjunto
{
    char *valores;
    char key;
};

typedef struct conjunto Conjunto;

#endif //PREDICTIONTABLE_CONJUNTO_H
