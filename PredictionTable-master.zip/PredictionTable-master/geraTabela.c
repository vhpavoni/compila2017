//
// Created by Victor on 16/10/2016.
//

#include <stdio.h>
#include "readgrammar.h"
#include "first.c"
#include "follow.c"
#include "geraTabela.h"


void geraPredTable(){


    for (int linha = 0; linha < (); linha++) {
        for (int coluna = 0; coluna < (); coluna) {

            case 1:{

            }

            case 2:{

            }

            case 3:{

            }
        }
        
    }

}